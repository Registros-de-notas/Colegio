// ============================================
// SISTEMA DE AUDITORÍA - ACTIVIDADES SOSPECHOSAS
// ============================================

// Variable global para la referencia de Firebase
window.AUDITORIA_REF = null;

// Función para inicializar la referencia de auditoría
function inicializarAuditoriaRef(db) {
    if (db && typeof db.ref === 'function') {
        window.AUDITORIA_REF = db.ref('auditoria');
        console.log('✅ Auditoría: Referencia a Firebase inicializada');
        return true;
    } else {
        console.warn('⚠️ Auditoría: No se proporcionó referencia a Firebase, usando solo localStorage');
        window.AUDITORIA_REF = null;
        return false;
    }
}

const AUDITORIA = {
    // Tipos de eventos a registrar
    TIPOS: {
        LOGIN_FALLIDO: 'login_fallido',
        LOGIN_EXITOSO: 'login_exitoso',
        CAMBIO_CONTRASEÑA: 'cambio_contraseña',
        EDICION_USUARIO: 'edicion_usuario',
        ELIMINACION_USUARIO: 'eliminacion_usuario',
        EDICION_NOTAS: 'edicion_notas',
        ELIMINACION_NOTAS: 'eliminacion_notas',
        EDICION_HORARIO: 'edicion_horario',
        ELIMINACION_HORARIO: 'eliminacion_horario',
        EDICION_PAGOS: 'edicion_pagos',
        ELIMINACION_PAGOS: 'eliminacion_pagos',
        APROBACION_SOLICITUD: 'aprobacion_solicitud',
        RECHAZO_SOLICITUD: 'rechazo_solicitud',
        ACCESO_NO_AUTORIZADO: 'acceso_no_autorizado',
        INTENTO_FUERZA_BRUTA: 'intento_fuerza_bruta',
        HORARIO_INUSUAL: 'horario_inusual',
        MULTIPLES_INTENTOS: 'multiples_intentos',
        CAMBIO_PERMISO: 'cambio_permiso',
        CAMBIO_SEVERIDAD: 'cambio_severidad',
        ELIMINACION_MASIVA: 'eliminacion_masiva',
        CAMBIO_ACCESO: 'cambio_acceso',
        BLOQUEO_ACCESO: 'bloqueo_acceso',
        DESBLOQUEO_ACCESO: 'desbloqueo_acceso'
    },

    // Niveles de severidad
    SEVERIDAD: {
        BAJA: 'baja',
        MEDIA: 'media',
        ALTA: 'alta',
        CRITICA: 'critica'
    },

    /**
     * Registrar una actividad en el sistema de auditoría
     */
    registrar: async function(tipo, severidad, usuario, descripcion, metadata = {}) {
        if (!tipo || !severidad || !usuario) {
            console.error('❌ Faltan datos para registrar auditoría');
            return null;
        }

        console.log(`📝 Registrando auditoría: ${tipo} - ${usuario}`);

        try {
            const registro = {
                id: Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                tipo: tipo,
                severidad: severidad,
                usuario: usuario,
                usuario_rol: this.obtenerRolUsuario(),
                descripcion: descripcion,
                metadata: metadata,
                ip: await this.obtenerIP(),
                user_agent: navigator.userAgent,
                fecha: new Date().toISOString(),
                timestamp: Date.now(),
                navegador: this.obtenerNavegador(),
                sistema_operativo: this.obtenerSO(),
                leida: false
            };

            // Intentar guardar en Firebase
            const firebaseGuardado = await this.guardarEnFirebase(registro);
            
            if (!firebaseGuardado) {
                // Si falla Firebase, guardar en localStorage
                this.guardarLocal(registro);
                console.log('💾 Actividad guardada en localStorage (fallback):', tipo);
            } else {
                console.log('✅ Actividad registrada en Firebase:', tipo);
            }

            // Si es de severidad alta o crítica, notificar
            if (severidad === 'alta' || severidad === 'critica') {
                this.notificarAlerta(registro);
            }

            // Detectar patrones sospechosos
            this.detectarPatronSospechoso(registro);

            // Guardar en caché local para rápido acceso
            this.guardarEnCache(registro);

            return registro;
        } catch (error) {
            console.error('❌ Error al registrar auditoría:', error);
            // Fallback a localStorage
            const registro = {
                id: Date.now() + '_' + Math.random().toString(36).substr(2, 9),
                tipo: tipo,
                severidad: severidad,
                usuario: usuario,
                usuario_rol: this.obtenerRolUsuario(),
                descripcion: descripcion,
                metadata: metadata,
                fecha: new Date().toISOString(),
                timestamp: Date.now(),
                local: true,
                leida: false
            };
            this.guardarLocal(registro);
            return registro;
        }
    },
    /**
     * Guardar en Firebase
     */
    guardarEnFirebase: async function(registro) {
        try {
            if (window.AUDITORIA_REF && typeof window.AUDITORIA_REF.push === 'function') {
                await window.AUDITORIA_REF.push(registro);
                return true;
            }
            return false;
        } catch (error) {
            console.error('Error al guardar en Firebase:', error);
            return false;
        }
    },

    /**
     * Guardar en localStorage
     */
    guardarLocal: function(registro) {
        const auditoriaLocal = JSON.parse(localStorage.getItem('auditoria_local') || '[]');
        auditoriaLocal.push(registro);
        localStorage.setItem('auditoria_local', JSON.stringify(auditoriaLocal));
    },

    /**
     * Guardar en caché para rápido acceso
     */
    guardarEnCache: function(registro) {
        try {
            const cache = JSON.parse(sessionStorage.getItem('auditoria_cache') || '[]');
            cache.unshift(registro);
            if (cache.length > 100) cache.pop(); // Mantener solo los últimos 100
            sessionStorage.setItem('auditoria_cache', JSON.stringify(cache));
        } catch (e) {
            // Ignorar errores de caché
        }
    },

    /**
     * Obtener el rol del usuario actual
     */
    obtenerRolUsuario: function() {
        try {
            const session = JSON.parse(sessionStorage.getItem('session') || 'null');
            return session?.rol || 'desconocido';
        } catch (e) {
            return 'desconocido';
        }
    },

    /**
     * Obtener todas las actividades
     */
    obtenerSospechosas: async function(filtros = {}) {
        try {
            let actividades = [];

            // Primero obtener de caché (rápido)
            const cache = JSON.parse(sessionStorage.getItem('auditoria_cache') || '[]');
            actividades = [...cache];

            // Intentar obtener de Firebase
            try {
                if (window.AUDITORIA_REF && typeof window.AUDITORIA_REF.once === 'function') {
                    // Ordenar por timestamp para obtener los más recientes
                    const snapshot = await window.AUDITORIA_REF
                        .orderByChild('timestamp')
                        .limitToLast(1000)
                        .once('value');
                    const datos = snapshot.val() || {};
                    const firebaseData = Object.values(datos);
                    // Combinar con caché, evitando duplicados
                    const ids = new Set(actividades.map(a => a.id));
                    firebaseData.forEach(a => {
                        if (!ids.has(a.id)) {
                            actividades.push(a);
                            ids.add(a.id);
                        }
                    });
                    console.log(`📊 Obtenidas ${firebaseData.length} actividades de Firebase`);
                }
            } catch (error) {
                console.error('❌ Error al obtener actividades de Firebase:', error);
                // Si hay error, usar solo localStorage
            }

            // Obtener de localStorage (fallback)
            const localData = JSON.parse(localStorage.getItem('auditoria_local') || '[]');
            const ids = new Set(actividades.map(a => a.id));
            localData.forEach(a => {
                if (!ids.has(a.id)) {
                    actividades.push(a);
                    ids.add(a.id);
                }
            });

            console.log(`📊 Total actividades: ${actividades.length}`);

            // Aplicar filtros
            if (filtros.tipo) {
                actividades = actividades.filter(a => a.tipo === filtros.tipo);
            }
            if (filtros.severidad) {
                actividades = actividades.filter(a => a.severidad === filtros.severidad);
            }
            if (filtros.usuario) {
                actividades = actividades.filter(a => a.usuario === filtros.usuario);
            }
            if (filtros.fecha_desde) {
                const desde = new Date(filtros.fecha_desde);
                actividades = actividades.filter(a => new Date(a.fecha) >= desde);
            }
            if (filtros.fecha_hasta) {
                const hasta = new Date(filtros.fecha_hasta);
                actividades = actividades.filter(a => new Date(a.fecha) <= hasta);
            }

            // Ordenar por fecha (más reciente primero)
            actividades.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));

            // Clasificar por severidad
            const clasificadas = {
                criticas: actividades.filter(a => a.severidad === 'critica'),
                altas: actividades.filter(a => a.severidad === 'alta'),
                medias: actividades.filter(a => a.severidad === 'media'),
                bajas: actividades.filter(a => a.severidad === 'baja'),
                total: actividades.length
            };

            return {
                todas: actividades,
                clasificadas: clasificadas,
                resumen: {
                    criticas: clasificadas.criticas.length,
                    altas: clasificadas.altas.length,
                    medias: clasificadas.medias.length,
                    bajas: clasificadas.bajas.length,
                    total: actividades.length
                }
            };
        } catch (error) {
            console.error('❌ Error al obtener actividades:', error);
            return { todas: [], clasificadas: {}, resumen: { total: 0 } };
        }
    },

    /**
     * Obtener una actividad específica por ID
     */
    obtenerActividad: async function(id) {
        try {
            // Buscar en caché primero
            const cache = JSON.parse(sessionStorage.getItem('auditoria_cache') || '[]');
            let actividad = cache.find(a => a.id === id);
            if (actividad) return actividad;

            // Buscar en localStorage
            const localData = JSON.parse(localStorage.getItem('auditoria_local') || '[]');
            actividad = localData.find(a => a.id === id);
            if (actividad) return actividad;

            // Buscar en Firebase
            if (window.AUDITORIA_REF && typeof window.AUDITORIA_REF.once === 'function') {
                const snapshot = await window.AUDITORIA_REF
                    .orderByChild('id')
                    .equalTo(id)
                    .once('value');
                const datos = snapshot.val() || {};
                const keys = Object.keys(datos);
                if (keys.length > 0) {
                    return { id: keys[0], ...datos[keys[0]] };
                }
            }

            return null;
        } catch (error) {
            console.error('Error al obtener actividad:', error);
            return null;
        }
    },

    /**
     * Marcar una actividad como leída
     */
    marcarLeida: async function(id) {
        try {
            // Marcar en caché
            const cache = JSON.parse(sessionStorage.getItem('auditoria_cache') || '[]');
            const cacheIndex = cache.findIndex(a => a.id === id);
            if (cacheIndex !== -1) {
                cache[cacheIndex].leida = true;
                sessionStorage.setItem('auditoria_cache', JSON.stringify(cache));
            }

            // Marcar en localStorage
            const localData = JSON.parse(localStorage.getItem('auditoria_local') || '[]');
            const localIndex = localData.findIndex(a => a.id === id);
            if (localIndex !== -1) {
                localData[localIndex].leida = true;
                localStorage.setItem('auditoria_local', JSON.stringify(localData));
            }

            // Marcar en Firebase
            if (window.AUDITORIA_REF && typeof window.AUDITORIA_REF.once === 'function') {
                const snapshot = await window.AUDITORIA_REF
                    .orderByChild('id')
                    .equalTo(id)
                    .once('value');
                const datos = snapshot.val() || {};
                const keys = Object.keys(datos);
                if (keys.length > 0) {
                    await window.AUDITORIA_REF.child(keys[0]).update({ leida: true });
                    return true;
                }
            }
            return true;
        } catch (error) {
            console.error('Error al marcar como leída:', error);
            return false;
        }
    },
    /**
     * Obtener el total de actividades no leídas
     */
    obtenerNoLeidas: async function() {
        try {
            const data = await this.obtenerSospechosas();
            return data.todas.filter(a => !a.leida).length;
        } catch (error) {
            console.error('Error al obtener actividades no leídas:', error);
            return 0;
        }
    },

    /**
     * Notificar alerta de seguridad
     */
    notificarAlerta: function(registro) {
        console.warn(`🚨 ALERTA DE SEGURIDAD: ${registro.tipo}`);
        console.warn(`   Severidad: ${registro.severidad}`);
        console.warn(`   Usuario: ${registro.usuario}`);
        console.warn(`   Descripción: ${registro.descripcion}`);

        // Guardar en localStorage para notificación visual
        const alertas = JSON.parse(localStorage.getItem('alertas_seguridad') || '[]');
        alertas.push({
            ...registro,
            leida: false
        });
        localStorage.setItem('alertas_seguridad', JSON.stringify(alertas));

        // Mostrar notificación visual
        this.mostrarNotificacion(registro);
    },

    /**
     * Mostrar notificación visual de seguridad
     */
    mostrarNotificacion: function(registro) {
        const notificacionesExistentes = document.querySelectorAll('.alerta-seguridad');
        if (notificacionesExistentes.length > 3) {
            notificacionesExistentes[0].remove();
        }

        const notificacion = document.createElement('div');
        notificacion.className = 'alerta-seguridad';
        notificacion.innerHTML = `
            <div class="alerta-seguridad-contenido">
                <span class="alerta-icono">🚨</span>
                <div class="alerta-texto">
                    <strong>ALERTA DE SEGURIDAD</strong>
                    <p>${registro.descripcion}</p>
                    <small>${new Date(registro.fecha).toLocaleTimeString()} · ${registro.usuario}</small>
                </div>
                <button class="alerta-cerrar" onclick="this.closest('.alerta-seguridad').remove()">✕</button>
            </div>
        `;
        document.body.appendChild(notificacion);

        setTimeout(() => {
            if (notificacion.parentElement) {
                notificacion.style.opacity = '0';
                notificacion.style.transition = 'opacity 0.5s';
                setTimeout(() => notificacion.remove(), 500);
            }
        }, 10000);
    },

    /**
     * Detectar patrones sospechosos
     */
    detectarPatronSospechoso: function(registro) {
        // 1. Múltiples intentos fallidos
        if (registro.tipo === 'login_fallido') {
            this.contarIntentosFallidos(registro.usuario).then(intentos => {
                if (intentos >= 5) {
                    this.registrar(
                        'multiples_intentos',
                        'alta',
                        registro.usuario,
                        `Múltiples intentos fallidos de inicio de sesión (${intentos})`,
                        { intentos: intentos }
                    );
                }
            });
        }

        // 2. Horario inusual
        const hora = new Date(registro.fecha).getHours();
        if (hora >= 0 && hora <= 5) {
            this.registrar(
                'horario_inusual',
                'media',
                registro.usuario,
                `Actividad en horario inusual (${hora}:00)`,
                { hora: hora }
            );
        }

        // 3. Múltiples eliminaciones
        if (registro.tipo === 'eliminacion_usuario' || registro.tipo === 'eliminacion_pagos') {
            this.contarEliminacionesRecientes(registro.usuario, registro.tipo).then(count => {
                if (count >= 3) {
                    this.registrar(
                        'eliminacion_masiva',
                        'alta',
                        registro.usuario,
                        `Múltiples eliminaciones (${count}) en poco tiempo`,
                        { tipo: registro.tipo, count: count }
                    );
                }
            });
        }

        // 4. Cambios de acceso (bloqueo/desbloqueo)
        if (registro.tipo === 'cambio_acceso') {
            const estado = registro.metadata?.estado ? 'desbloqueado' : 'bloqueado';
            const rol = registro.metadata?.rol || 'rol desconocido';
            this.registrar(
                estado === 'bloqueado' ? 'bloqueo_acceso' : 'desbloqueo_acceso',
                'media',
                registro.usuario,
                `${rol} ${estado} por ${registro.usuario}`,
                { rol: rol, estado: estado }
            );
        }
    },

    /**
     * Contar intentos fallidos
     */
    contarIntentosFallidos: async function(usuario) {
        try {
            const data = await this.obtenerSospechosas();
            const fallidos = data.todas.filter(a =>
                a.tipo === 'login_fallido' &&
                a.usuario === usuario &&
                (Date.now() - (a.timestamp || 0)) < 600000
            );
            return fallidos.length;
        } catch (error) {
            return 0;
        }
    },

    /**
     * Contar eliminaciones recientes
     */
    contarEliminacionesRecientes: async function(usuario, tipo) {
        try {
            const data = await this.obtenerSospechosas();
            const eliminaciones = data.todas.filter(a =>
                a.tipo === tipo &&
                a.usuario === usuario &&
                (Date.now() - (a.timestamp || 0)) < 300000
            );
            return eliminaciones.length;
        } catch (error) {
            return 0;
        }
    },
    /**
     * Obtener IP del usuario
     */
    obtenerIP: function() {
        return new Promise((resolve) => {
            try {
                fetch('https://api.ipify.org?format=json')
                    .then(res => res.json())
                    .then(data => resolve(data.ip || 'no_disponible'))
                    .catch(() => resolve('no_disponible'));
            } catch (error) {
                resolve('no_disponible');
            }
        });
    },

    /**
     * Obtener navegador
     */
    obtenerNavegador: function() {
        const ua = navigator.userAgent;
        if (ua.includes('Chrome')) return 'Chrome';
        if (ua.includes('Firefox')) return 'Firefox';
        if (ua.includes('Safari')) return 'Safari';
        if (ua.includes('Edge')) return 'Edge';
        if (ua.includes('Opera')) return 'Opera';
        return 'Otro';
    },

    /**
     * Obtener sistema operativo
     */
    obtenerSO: function() {
        const ua = navigator.userAgent;
        if (ua.includes('Windows')) return 'Windows';
        if (ua.includes('Mac')) return 'MacOS';
        if (ua.includes('Linux')) return 'Linux';
        if (ua.includes('Android')) return 'Android';
        if (ua.includes('iOS')) return 'iOS';
        return 'Otro';
    },

    /**
     * Generar reporte
     */
    generarReporte: async function(filtros = {}) {
        const data = await this.obtenerSospechosas(filtros);
        const ahora = new Date();

        return {
            fecha_generacion: ahora.toISOString(),
            fecha_hora: ahora.toLocaleString('es-ES'),
            filtros_aplicados: filtros,
            resumen: data.resumen,
            actividades: data.todas.slice(0, 100),
            total_registros: data.todas.length
        };
    },

    /**
     * Exportar a CSV
     */
    exportarCSV: async function(filtros = {}) {
        const data = await this.obtenerSospechosas(filtros);
        const actividades = data.todas;

        if (actividades.length === 0) {
            alert('No hay datos para exportar');
            return;
        }

        const headers = ['Fecha', 'Usuario', 'Rol', 'Tipo', 'Severidad', 'Descripción', 'IP', 'Navegador'];
        const rows = actividades.map(a => [
            new Date(a.fecha).toLocaleString('es-ES'),
            a.usuario || 'Desconocido',
            a.usuario_rol || 'desconocido',
            a.tipo || 'desconocido',
            a.severidad || 'baja',
            a.descripcion || 'Sin descripción',
            a.ip || 'N/A',
            a.navegador || 'N/A'
        ]);

        let csv = headers.join(',') + '\n';
        rows.forEach(row => {
            csv += row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',') + '\n';
        });

        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        link.href = URL.createObjectURL(blob);
        link.download = `auditoria_${new Date().toISOString().slice(0, 10)}.csv`;
        link.click();
        URL.revokeObjectURL(link.href);
    },

    /**
     * Verificar estado del sistema
     */
    verificarEstado: function() {
        const estado = {
            firebase_disponible: window.AUDITORIA_REF !== null && typeof window.AUDITORIA_REF.push === 'function',
            local_storage_disponible: typeof localStorage !== 'undefined',
            session_storage_disponible: typeof sessionStorage !== 'undefined',
            total_cache: JSON.parse(sessionStorage.getItem('auditoria_cache') || '[]').length,
            total_local: JSON.parse(localStorage.getItem('auditoria_local') || '[]').length,
            alertas_pendientes: JSON.parse(localStorage.getItem('alertas_seguridad') || '[]').length
        };
        console.log('📊 Estado del sistema de auditoría:', estado);
        return estado;
    }
};

// ============================================
// EXPORTAR PARA USO EN OTROS ARCHIVOS
// ============================================

// Hacer disponible globalmente
window.AUDITORIA = AUDITORIA;
window.inicializarAuditoriaRef = inicializarAuditoriaRef;

// ============================================
// ESTILOS PARA NOTIFICACIONES
// ============================================

(function agregarEstilosAuditoria() {
    if (document.querySelector('#estilos-auditoria')) return;

    const estiloAlerta = document.createElement('style');
    estiloAlerta.id = 'estilos-auditoria';
    estiloAlerta.textContent = `
        .alerta-seguridad {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 10000;
            background: #dc3545;
            color: white;
            border-radius: 12px;
            box-shadow: 0 10px 40px rgba(220, 53, 69, 0.4);
            max-width: 400px;
            animation: slideInAudit 0.5s ease;
            padding: 15px 20px;
            border-left: 5px solid #ff6b6b;
        }

        @keyframes slideInAudit {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        .alerta-seguridad-contenido {
            display: flex;
            align-items: flex-start;
            gap: 12px;
        }

        .alerta-seguridad .alerta-icono {
            font-size: 28px;
            flex-shrink: 0;
        }

        .alerta-seguridad .alerta-texto {
            flex: 1;
        }

        .alerta-seguridad .alerta-texto strong {
            display: block;
            font-size: 14px;
            margin-bottom: 4px;
        }

        .alerta-seguridad .alerta-texto p {
            margin: 0;
            font-size: 13px;
            opacity: 0.9;
        }

        .alerta-seguridad .alerta-texto small {
            font-size: 11px;
            opacity: 0.7;
            display: block;
            margin-top: 3px;
        }

        .alerta-seguridad .alerta-cerrar {
            background: none;
            border: none;
            color: white;
            font-size: 18px;
            cursor: pointer;
            opacity: 0.7;
            padding: 0 5px;
            flex-shrink: 0;
        }

        .alerta-seguridad .alerta-cerrar:hover {
            opacity: 1;
        }

        .badge-auditoria {
            background: #dc3545;
            color: white;
            border-radius: 50%;
            padding: 2px 8px;
            font-size: 11px;
            font-weight: bold;
            position: absolute;
            top: -8px;
            right: -8px;
            min-width: 20px;
            text-align: center;
            animation: pulse-badge 2s infinite;
        }

        @keyframes pulse-badge {
            0% { transform: scale(1); }
            50% { transform: scale(1.1); }
            100% { transform: scale(1); }
        }

        .panel-auditoria {
            background: white;
            border-radius: 12px;
            padding: 20px;
            margin: 20px 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .panel-auditoria h3 {
            margin-top: 0;
            color: #333;
            border-bottom: 2px solid #eee;
            padding-bottom: 10px;
        }

        .estadisticas-auditoria {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin: 15px 0;
        }

        .estadistica-item {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
        }

        .estadistica-item .numero {
            font-size: 24px;
            font-weight: bold;
            display: block;
        }

        .estadistica-item .label {
            font-size: 12px;
            color: #666;
        }

        .estadistica-item.critica .numero { color: #dc3545; }
        .estadistica-item.alta .numero { color: #fd7e14; }
        .estadistica-item.media .numero { color: #ffc107; }
        .estadistica-item.baja .numero { color: #28a745; }
    `;
    document.head.appendChild(estiloAlerta);
})();

// ============================================
// MENSAJE FINAL
// ============================================

console.log('✅ Sistema de Auditoría cargado correctamente');
console.log('📋 Funciones disponibles:');
console.log('  - AUDITORIA.registrar()');
console.log('  - AUDITORIA.obtenerSospechosas()');
console.log('  - AUDITORIA.obtenerActividad()');
console.log('  - AUDITORIA.marcarLeida()');
console.log('  - AUDITORIA.generarReporte()');
console.log('  - AUDITORIA.exportarCSV()');
console.log('  - AUDITORIA.verificarEstado()');
console.log('  - inicializarAuditoriaRef(db)');