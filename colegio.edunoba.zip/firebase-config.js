// ============================================
// CONFIGURACIÓN DE FIREBASE
// ============================================

const firebaseConfig = {
    apiKey: "AIzaSyAdL70mCS1oX3QigWl3dr1glvoUk7MOKzM",
    authDomain: "colegio-edunova.firebaseapp.com",
    databaseURL: "https://colegio-edunova-default-rtdb.firebaseio.com",
    projectId: "colegio-edunova",
    storageBucket: "colegio-edunova.firebasestorage.app",
    messagingSenderId: "350906702632",
    appId: "1:350906702632:web:dd0f3bd165842fe10de1d",
    measurementId: "G-6QKP7E3N97"
};

// ============================================
// DETECTAR SI ESTAMOS EN file://
// ============================================

const esFileProtocol = window.location.protocol === 'file:';

if (esFileProtocol) {
    console.warn('⚠️⚠️⚠️ EJECUTANDO EN file:// - APLICANDO PARCHES ⚠️⚠️⚠️');
    console.warn('⚠️ Se recomienda usar Live Server o un servidor HTTP');
    console.warn('⚠️ https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer');
}

// ============================================
// VARIABLES GLOBALES
// ============================================

let firebaseReady = false;
let database = null;
let firebaseInicializado = false;
let intentosInicializacion = 0;
const MAX_INTENTOS = 10;

// ============================================
// FUNCIÓN PARA ESPERAR A QUE FIREBASE ESTÉ DISPONIBLE
// ============================================

function esperarFirebase() {
    return new Promise((resolve) => {
        // Si ya está disponible, resolver inmediatamente
        if (typeof firebase !== 'undefined' && firebase.initializeApp) {
            console.log('✅ Firebase ya está disponible');
            resolve(true);
            return;
        }

        console.log('⏳ Esperando que Firebase se cargue...');
        
        let intentos = 0;
        const maxIntentos = 30;
        const checkInterval = setInterval(() => {
            intentos++;
            
            if (typeof firebase !== 'undefined' && firebase.initializeApp) {
                clearInterval(checkInterval);
                console.log('✅ Firebase detectado después de', intentos, 'intentos');
                resolve(true);
            } else if (intentos >= maxIntentos) {
                clearInterval(checkInterval);
                console.error('❌ Firebase no se detectó después de', maxIntentos, 'intentos');
                resolve(false);
            }
        }, 300);
    });
}

// ============================================
// INICIALIZACIÓN PRINCIPAL DE FIREBASE
// ============================================

async function initFirebase() {
    // Si ya está inicializado, resolver inmediatamente
    if (firebaseInicializado && database) {
        console.log('🔥 Firebase ya estaba inicializado');
        return true;
    }

    try {
        // Esperar a que Firebase esté disponible
        const disponible = await esperarFirebase();
        if (!disponible) {
            console.error('❌ Firebase no está disponible');
            mostrarErrorFirebase('Firebase no se cargó correctamente. Verifica tu conexión a internet.');
            return false;
        }

        // Verificar si ya hay apps inicializadas
        if (firebase.apps && firebase.apps.length > 0) {
            console.log('🔥 Firebase ya tenía apps inicializadas');
            firebaseInicializado = true;
            database = firebase.database();
            firebaseReady = true;
            verificarConexionFirebase();
            return true;
        }

        // Inicializar nueva app
        firebase.initializeApp(firebaseConfig);
        console.log('🔥 Firebase inicializado correctamente');
        
        firebaseInicializado = true;
        database = firebase.database();
        firebaseReady = true;
        
        // Verificar conexión después de un momento
        setTimeout(() => {
            verificarConexionFirebase();
        }, 500);

        return true;

    } catch (error) {
        console.error('❌ Error al inicializar Firebase:', error);
        firebaseInicializado = false;
        database = null;
        firebaseReady = false;
        mostrarErrorFirebase('Error al inicializar Firebase: ' + error.message);
        return false;
    }
}

// ============================================
// VERIFICAR CONEXIÓN CON FIREBASE EN TIEMPO REAL
// ============================================

function verificarConexionFirebase() {
    const db = getDatabase();
    if (!db) {
        console.error('❌ Firebase no está disponible para verificar conexión');
        return false;
    }

    try {
        const connectedRef = db.ref('.info/connected');
        connectedRef.on('value', (snap) => {
            const estado = snap.val() === true;
            if (estado) {
                console.log('✅ Conectado a Firebase');
                ocultarErrorFirebase();
                // Actualizar UI si existe
                const estadoEl = document.getElementById('estadoConexion');
                if (estadoEl) {
                    estadoEl.textContent = '✅ Conectado';
                    estadoEl.className = 'conectado';
                    estadoEl.style.display = 'inline-block';
                }
                // Actualizar el estado en la página de login
                const loginEstado = document.getElementById('estadoConexionLogin');
                if (loginEstado) {
                    loginEstado.textContent = '✅ Conectado';
                    loginEstado.className = 'conectado';
                    loginEstado.style.display = 'inline-block';
                }
            } else {
                console.warn('⚠️ Desconectado de Firebase');
                mostrarErrorFirebase('Desconectado de Firebase. Verifica tu conexión a internet.');
                const estadoEl = document.getElementById('estadoConexion');
                if (estadoEl) {
                    estadoEl.textContent = '❌ Desconectado';
                    estadoEl.className = 'desconectado';
                    estadoEl.style.display = 'inline-block';
                }
                const loginEstado = document.getElementById('estadoConexionLogin');
                if (loginEstado) {
                    loginEstado.textContent = '❌ Desconectado';
                    loginEstado.className = 'desconectado';
                    loginEstado.style.display = 'inline-block';
                }
            }
        });
        return true;
    } catch (error) {
        console.error('❌ Error al verificar conexión:', error);
        return false;
    }
}

// ============================================
// OBTENER INSTANCIA DE LA BASE DE DATOS
// ============================================

function getDatabase() {
    if (database) return database;
    
    try {
        if (firebaseReady && typeof firebase !== 'undefined') {
            database = firebase.database();
            return database;
        }
    } catch (error) {
        console.error('❌ Error al obtener database:', error);
    }
    return null;
}

// ============================================
// CREAR REFERENCIA A UNA RUTA DE FIREBASE
// ============================================

function crearReferencia(path) {
    try {
        const db = getDatabase();
        if (db) {
            return db.ref(path);
        }
        if (firebaseReady && typeof firebase !== 'undefined') {
            return firebase.database().ref(path);
        }
        console.warn(`⚠️ No se pudo crear referencia a ${path}`);
        return null;
    } catch (error) {
        console.error(`❌ Error al crear referencia ${path}:`, error);
        return null;
    }
}

// ============================================
// MOSTRAR ERROR EN LA INTERFAZ
// ============================================

function mostrarErrorFirebase(mensaje) {
    // Mostrar en consola
    console.error('❌ Error Firebase:', mensaje);
    
    // Buscar contenedor de error en admin-principal.html
    const errorContainer = document.getElementById('firebaseError');
    if (errorContainer) {
        errorContainer.style.display = 'block';
        errorContainer.innerHTML = `
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i>
                <strong>Error de conexión:</strong> ${mensaje || 'Firebase no está disponible'}
                <br><small>Verifica tu conexión a internet o recarga la página.</small>
                <br>
                <button class="btn btn-primary btn-sm mt-2" onclick="window.recargarFirebase ? recargarFirebase() : location.reload()">
                    <i class="bi bi-arrow-repeat"></i> Reconectar
                </button>
                <button class="btn btn-secondary btn-sm mt-2" onclick="location.reload()">
                    <i class="bi bi-arrow-clockwise"></i> Recargar
                </button>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
    }
    
    // Buscar contenedor de error en index.html (login)
    const loginError = document.getElementById('loginError');
    if (loginError) {
        loginError.style.display = 'block';
        const errorMsg = document.getElementById('errorMessage');
        if (errorMsg) {
            errorMsg.textContent = '⚠️ ' + mensaje;
        }
    }
}

function ocultarErrorFirebase() {
    const errorContainer = document.getElementById('firebaseError');
    if (errorContainer) {
        errorContainer.style.display = 'none';
        errorContainer.innerHTML = '';
    }
    const loginError = document.getElementById('loginError');
    if (loginError) {
        loginError.style.display = 'none';
    }
}

// ============================================
// RECARGAR FIREBASE COMPLETAMENTE
// ============================================

function recargarFirebase() {
    console.log('🔄 Recargando Firebase...');
    intentosInicializacion++;
    
    try {
        // Eliminar apps existentes
        if (typeof firebase !== 'undefined' && firebase.apps && firebase.apps.length > 0) {
            firebase.apps.forEach(app => {
                try {
                    app.delete();
                    console.log('✅ App de Firebase eliminada');
                } catch (e) {
                    console.warn('⚠️ No se pudo eliminar app:', e);
                }
            });
        }
    } catch (error) {
        console.warn('⚠️ No se pudieron eliminar las apps:', error);
    }
    
    // Reiniciar estado
    firebaseInicializado = false;
    database = null;
    firebaseReady = false;
    
    // Mostrar mensaje de reconexión
    const estadoEl = document.getElementById('estadoConexion');
    if (estadoEl) {
        estadoEl.textContent = '🔄 Reconectando...';
        estadoEl.className = 'cargando';
        estadoEl.style.display = 'inline-block';
    }
    
    // Reiniciar después de un momento
    setTimeout(async () => {
        const success = await initFirebase();
        if (success) {
            console.log('✅ Firebase recargado correctamente');
            verificarReferencias();
            // Intentar recargar la sección actual
            const activeSection = document.querySelector('.nav-link.active');
            if (activeSection && activeSection.dataset.section) {
                const section = activeSection.dataset.section;
                if (typeof cargarSeccion === 'function') {
                    setTimeout(() => cargarSeccion(section), 500);
                }
            }
            if (typeof mostrarToast === 'function') {
                mostrarToast('✅ Reconectado a Firebase');
            }
        } else {
            console.error('❌ No se pudo recargar Firebase');
            if (intentosInicializacion < MAX_INTENTOS) {
                setTimeout(recargarFirebase, 3000);
            } else {
                alert('❌ No se pudo conectar con Firebase después de varios intentos. Verifica tu conexión a internet.');
            }
        }
    }, 500);
}

// ============================================
// CREAR TODAS LAS REFERENCIAS
// ============================================

const USUARIOS_REF = crearReferencia('usuarios');
const NOTAS_REF = crearReferencia('notas');
const ASISTENCIAS_REF = crearReferencia('asistencias');
const ANUNCIOS_REF = crearReferencia('anuncios');
const CONFIG_REF = crearReferencia('configuracion');
const FECHAS_REF = crearReferencia('fechasModulos');
const NOMBRE_COLUMNAS_REF = crearReferencia('nombreColumnas');
const NOMBRES_MODULOS_REF = crearReferencia('nombresModulos');
const PERMISOS_REF = crearReferencia('permisos');
const HORARIOS_REF = crearReferencia('horarios');
const ENCUESTAS_REF = crearReferencia('encuestas_docentes');
const PAGOS_REF = crearReferencia('pagos');
const SOLICITUDES_REF = crearReferencia('solicitudes_cambio_contraseña');
const AUDITORIA_REF = crearReferencia('auditoria');
const EVOLUCION_REF = crearReferencia('evolucion_alumnos');
const EXAMENES_REF = crearReferencia('examenes');
const RESPUESTAS_EXAMEN_REF = crearReferencia('respuestas_examen');
const RANKING_REF = crearReferencia('ranking');
const KPI_REF = crearReferencia('kpi');
const RECONOCIMIENTOS_REF = crearReferencia('reconocimientos');
const TUTORIAS_REF = crearReferencia('tutorias');
const INCIDENCIAS_REF = crearReferencia('incidencias');
const CONVIVENCIA_REF = crearReferencia('convivencia');
const BITACORA_REF = crearReferencia('bitacora_tutoria');
const SEGURIDAD_REF = crearReferencia('seguridad');

// ============================================
// VERIFICAR TODAS LAS REFERENCIAS
// ============================================

function verificarReferencias() {
    const referencias = {
        'USUARIOS_REF': USUARIOS_REF,
        'NOTAS_REF': NOTAS_REF,
        'ASISTENCIAS_REF': ASISTENCIAS_REF,
        'ANUNCIOS_REF': ANUNCIOS_REF,
        'CONFIG_REF': CONFIG_REF,
        'FECHAS_REF': FECHAS_REF,
        'NOMBRE_COLUMNAS_REF': NOMBRE_COLUMNAS_REF,
        'NOMBRES_MODULOS_REF': NOMBRES_MODULOS_REF,
        'PERMISOS_REF': PERMISOS_REF,
        'HORARIOS_REF': HORARIOS_REF,
        'ENCUESTAS_REF': ENCUESTAS_REF,
        'PAGOS_REF': PAGOS_REF,
        'SOLICITUDES_REF': SOLICITUDES_REF,
        'AUDITORIA_REF': AUDITORIA_REF,
        'EVOLUCION_REF': EVOLUCION_REF,
        'EXAMENES_REF': EXAMENES_REF,
        'RESPUESTAS_EXAMEN_REF': RESPUESTAS_EXAMEN_REF,
        'RANKING_REF': RANKING_REF,
        'KPI_REF': KPI_REF,
        'RECONOCIMIENTOS_REF': RECONOCIMIENTOS_REF,
        'TUTORIAS_REF': TUTORIAS_REF,
        'INCIDENCIAS_REF': INCIDENCIAS_REF,
        'CONVIVENCIA_REF': CONVIVENCIA_REF,
        'BITACORA_REF': BITACORA_REF,
        'SEGURIDAD_REF': SEGURIDAD_REF
    };
    
    console.log('📋 Verificando referencias:');
    let todasOk = true;
    for (const [nombre, ref] of Object.entries(referencias)) {
        const estado = ref ? '✅' : '❌';
        console.log(`  - ${nombre}: ${estado}`);
        if (!ref) todasOk = false;
    }
    
    if (!todasOk) {
        console.warn('⚠️ Algunas referencias no están disponibles');
        // Intentar reconectar después de un momento
        setTimeout(() => {
            reconectarReferencias();
        }, 1000);
    } else {
        console.log('✅ Todas las referencias están disponibles');
    }
    
    return { todasOk, resultado: referencias };
}

// ============================================
// RECONECTAR REFERENCIAS
// ============================================

function reconectarReferencias() {
    console.log('🔄 Intentando reconectar referencias...');
    
    const referenciasPendientes = [
        { nombre: 'USUARIOS_REF', path: 'usuarios' },
        { nombre: 'NOTAS_REF', path: 'notas' },
        { nombre: 'ASISTENCIAS_REF', path: 'asistencias' },
        { nombre: 'ANUNCIOS_REF', path: 'anuncios' },
        { nombre: 'CONFIG_REF', path: 'configuracion' },
        { nombre: 'FECHAS_REF', path: 'fechasModulos' },
        { nombre: 'NOMBRE_COLUMNAS_REF', path: 'nombreColumnas' },
        { nombre: 'NOMBRES_MODULOS_REF', path: 'nombresModulos' },
        { nombre: 'PERMISOS_REF', path: 'permisos' },
        { nombre: 'HORARIOS_REF', path: 'horarios' },
        { nombre: 'ENCUESTAS_REF', path: 'encuestas_docentes' },
        { nombre: 'PAGOS_REF', path: 'pagos' },
        { nombre: 'SOLICITUDES_REF', path: 'solicitudes_cambio_contraseña' },
        { nombre: 'AUDITORIA_REF', path: 'auditoria' },
        { nombre: 'EVOLUCION_REF', path: 'evolucion_alumnos' },
        { nombre: 'EXAMENES_REF', path: 'examenes' },
        { nombre: 'RESPUESTAS_EXAMEN_REF', path: 'respuestas_examen' },
        { nombre: 'RANKING_REF', path: 'ranking' },
        { nombre: 'KPI_REF', path: 'kpi' },
        { nombre: 'RECONOCIMIENTOS_REF', path: 'reconocimientos' },
        { nombre: 'TUTORIAS_REF', path: 'tutorias' },
        { nombre: 'INCIDENCIAS_REF', path: 'incidencias' },
        { nombre: 'CONVIVENCIA_REF', path: 'convivencia' },
        { nombre: 'BITACORA_REF', path: 'bitacora_tutoria' },
        { nombre: 'SEGURIDAD_REF', path: 'seguridad' }
    ];
    
    referenciasPendientes.forEach(({ nombre, path }) => {
        if (!window[nombre]) {
            const ref = crearReferencia(path);
            if (ref) {
                window[nombre] = ref;
                console.log(`✅ Reconectado: ${nombre}`);
            }
        }
    });
}

// ============================================
// EXPORTAR PARA USO GLOBAL
// ============================================

// Hacer disponibles globalmente
window.USUARIOS_REF = USUARIOS_REF;
window.NOTAS_REF = NOTAS_REF;
window.ASISTENCIAS_REF = ASISTENCIAS_REF;
window.ANUNCIOS_REF = ANUNCIOS_REF;
window.CONFIG_REF = CONFIG_REF;
window.FECHAS_REF = FECHAS_REF;
window.NOMBRE_COLUMNAS_REF = NOMBRE_COLUMNAS_REF;
window.NOMBRES_MODULOS_REF = NOMBRES_MODULOS_REF;
window.PERMISOS_REF = PERMISOS_REF;
window.HORARIOS_REF = HORARIOS_REF;
window.ENCUESTAS_REF = ENCUESTAS_REF;
window.PAGOS_REF = PAGOS_REF;
window.SOLICITUDES_REF = SOLICITUDES_REF;
window.AUDITORIA_REF = AUDITORIA_REF;
window.EVOLUCION_REF = EVOLUCION_REF;
window.EXAMENES_REF = EXAMENES_REF;
window.RESPUESTAS_EXAMEN_REF = RESPUESTAS_EXAMEN_REF;
window.RANKING_REF = RANKING_REF;
window.KPI_REF = KPI_REF;
window.RECONOCIMIENTOS_REF = RECONOCIMIENTOS_REF;
window.TUTORIAS_REF = TUTORIAS_REF;
window.INCIDENCIAS_REF = INCIDENCIAS_REF;
window.CONVIVENCIA_REF = CONVIVENCIA_REF;
window.BITACORA_REF = BITACORA_REF;
window.SEGURIDAD_REF = SEGURIDAD_REF;

window.firebaseReady = firebaseReady;
window.recargarFirebase = recargarFirebase;
window.initFirebase = initFirebase;
window.verificarReferencias = verificarReferencias;
window.getDatabase = getDatabase;
window.crearReferencia = crearReferencia;

// ============================================
// INICIALIZACIÓN AUTOMÁTICA
// ============================================

// Iniciar Firebase automáticamente al cargar
(async function iniciar() {
    console.log('🚀 Iniciando Firebase automáticamente...');
    const success = await initFirebase();
    
    if (success) {
        console.log('✅ Firebase listo para usar');
        setTimeout(verificarReferencias, 800);
    } else {
        console.error('❌ No se pudo inicializar Firebase');
        // Reintentar después de 3 segundos
        setTimeout(async () => {
            if (!firebaseReady) {
                console.log('🔄 Reintentando inicialización...');
                await initFirebase();
            }
        }, 3000);
    }
})();

// Agregar evento para recargar cuando la página vuelve a tener foco
document.addEventListener('visibilitychange', () => {
    if (!document.hidden && !firebaseReady) {
        console.log('🔄 Reconectando Firebase al volver a la página...');
        initFirebase();
    }
});

// Agregar evento para detectar cambios en la conexión de red
window.addEventListener('online', () => {
    console.log('🌐 Conexión de red restablecida');
    if (!firebaseReady) {
        recargarFirebase();
    }
});

// ============================================
// MENSAJE FINAL
// ============================================

console.log('✅ firebase-config.js cargado correctamente');
console.log(`📅 Fecha: ${new Date().toLocaleString()}`);
console.log(`📁 Protocolo: ${window.location.protocol}`);

if (esFileProtocol) {
    console.warn('⚠️⚠️⚠️ ESTÁS EJECUTANDO EN file:// ⚠️⚠️⚠️');
    console.warn('⚠️ Firebase PUEDE NO FUNCIONAR correctamente');
    console.warn('⚠️ Usa Live Server de VS Code o un servidor HTTP');
    console.warn('⚠️ https://marketplace.visualstudio.com/items?itemName=ritwickdey.LiveServer');
} else {
    console.log('✅ Usando protocolo HTTP/HTTPS - Todo bien');
}