// ============================================
// SISTEMA DE SEGURIDAD Y AUTENTICACIÓN 2FA
// ============================================

const SEGURIDAD = {
    /**
     * Generar código 2FA de 6 dígitos
     */
    generarCodigo2FA: function() {
        return String(Math.floor(100000 + Math.random() * 900000));
    },

    /**
     * Activar 2FA para un usuario
     */
    activar2FA: async function(usuarioDni, codigo = null) {
        if (!usuarioDni) {
            console.error('❌ DNI del usuario requerido');
            return null;
        }

        const codigoGenerado = codigo || this.generarCodigo2FA();
        const expiracion = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString();

        if (typeof SEGURIDAD_REF === 'undefined' || SEGURIDAD_REF === null) {
            console.warn('⚠️ SEGURIDAD_REF no disponible, guardando en localStorage');
            this.guardarLocal(usuarioDni, {
                activo: true,
                codigo: codigoGenerado,
                expiracion: expiracion
            });
            return codigoGenerado;
        }

        try {
            await SEGURIDAD_REF.child('2fa').child(usuarioDni).set({
                activo: true,
                codigo: codigoGenerado,
                expiracion: expiracion,
                fecha_activacion: new Date().toISOString()
            });

            console.log('✅ 2FA activado para:', usuarioDni);
            
            if (typeof AUDITORIA !== 'undefined' && AUDITORIA.registrar) {
                AUDITORIA.registrar(
                    'activacion_2fa',
                    'alta',
                    usuarioDni,
                    'Autenticación de dos factores activada',
                    {}
                );
            }

            return codigoGenerado;
        } catch (error) {
            console.error('❌ Error al activar 2FA:', error);
            this.guardarLocal(usuarioDni, {
                activo: true,
                codigo: codigoGenerado,
                expiracion: expiracion
            });
            return codigoGenerado;
        }
    },

    /**
     * Desactivar 2FA para un usuario
     */
    desactivar2FA: async function(usuarioDni) {
        if (!usuarioDni) {
            console.error('❌ DNI del usuario requerido');
            return false;
        }

        if (typeof SEGURIDAD_REF === 'undefined' || SEGURIDAD_REF === null) {
            localStorage.removeItem('seguridad_2fa_' + usuarioDni);
            return true;
        }

        try {
            await SEGURIDAD_REF.child('2fa').child(usuarioDni).remove();
            console.log('✅ 2FA desactivado para:', usuarioDni);
            
            if (typeof AUDITORIA !== 'undefined' && AUDITORIA.registrar) {
                AUDITORIA.registrar(
                    'desactivacion_2fa',
                    'alta',
                    usuarioDni,
                    'Autenticación de dos factores desactivada',
                    {}
                );
            }

            return true;
        } catch (error) {
            console.error('❌ Error al desactivar 2FA:', error);
            return false;
        }
    },

    /**
     * Verificar código 2FA
     */
    verificarCodigo2FA: async function(usuarioDni, codigoIngresado) {
        if (!usuarioDni || !codigoIngresado) {
            console.error('❌ DNI y código requeridos');
            return false;
        }

        try {
            let config = null;

            // Buscar en Firebase
            if (typeof SEGURIDAD_REF !== 'undefined' && SEGURIDAD_REF !== null) {
                const snap = await SEGURIDAD_REF.child('2fa').child(usuarioDni).once('value');
                config = snap.val();
            }

            // Si no está en Firebase, buscar en localStorage
            if (!config) {
                const localData = localStorage.getItem('seguridad_2fa_' + usuarioDni);
                if (localData) {
                    config = JSON.parse(localData);
                }
            }

            if (!config) {
                console.warn('⚠️ No hay configuración 2FA para:', usuarioDni);
                return false;
            }

            // Verificar si está activo
            if (config.activo !== true) {
                console.warn('⚠️ 2FA no está activo para:', usuarioDni);
                return false;
            }

            // Verificar expiración
            if (config.expiracion) {
                const expiracion = new Date(config.expiracion);
                if (new Date() > expiracion) {
                    console.warn('⚠️ Código 2FA expirado para:', usuarioDni);
                    // Desactivar automáticamente
                    await this.desactivar2FA(usuarioDni);
                    return false;
                }
            }

            // Verificar código
            const codigoValido = config.codigo === codigoIngresado;
            
            if (codigoValido) {
                console.log('✅ Código 2FA verificado para:', usuarioDni);
                if (typeof AUDITORIA !== 'undefined' && AUDITORIA.registrar) {
                    AUDITORIA.registrar(
                        'verificacion_2fa',
                        'baja',
                        usuarioDni,
                        'Código 2FA verificado correctamente',
                        {}
                    );
                }
            } else {
                console.warn('⚠️ Código 2FA incorrecto para:', usuarioDni);
                if (typeof AUDITORIA !== 'undefined' && AUDITORIA.registrar) {
                    AUDITORIA.registrar(
                        'fallo_2fa',
                        'media',
                        usuarioDni,
                        'Intento fallido de verificación 2FA',
                        {}
                    );
                }
            }

            return codigoValido;
        } catch (error) {
            console.error('❌ Error al verificar 2FA:', error);
            return false;
        }
    },

    /**
     * Obtener estado 2FA de un usuario
     */
    obtenerEstado2FA: async function(usuarioDni) {
        if (!usuarioDni) return null;

        try {
            let config = null;

            if (typeof SEGURIDAD_REF !== 'undefined' && SEGURIDAD_REF !== null) {
                const snap = await SEGURIDAD_REF.child('2fa').child(usuarioDni).once('value');
                config = snap.val();
            }

            if (!config) {
                const localData = localStorage.getItem('seguridad_2fa_' + usuarioDni);
                if (localData) {
                    config = JSON.parse(localData);
                }
            }

            if (!config) {
                return { activo: false, codigo: null, expiracion: null };
            }

            return {
                activo: config.activo === true,
                codigo: config.codigo || null,
                expiracion: config.expiracion || null,
                fecha_activacion: config.fecha_activacion || null
            };
        } catch (error) {
            console.error('❌ Error al obtener estado 2FA:', error);
            return { activo: false, codigo: null, expiracion: null };
        }
    },

    /**
     * Registrar intento de login fallido
     */
    registrarLoginFallido: async function(usuario, ip = null) {
        if (!usuario) return;

        try {
            if (typeof AUDITORIA_REF === 'undefined' || AUDITORIA_REF === null) {
                return;
            }

            // Contar intentos fallidos en los últimos 5 minutos
            const cincoMinutos = Date.now() - 300000;
            const snap = await AUDITORIA_REF
                .orderByChild('timestamp')
                .startAt(cincoMinutos)
                .once('value');
            
            const data = snap.val() || {};
            const fallidos = Object.values(data).filter(a => 
                a.usuario === usuario && a.tipo === 'login_fallido'
            );

            // Si hay más de 5 intentos fallidos, registrar como sospechoso
            if (fallidos.length >= 5) {
                if (typeof AUDITORIA !== 'undefined' && AUDITORIA.registrar) {
                    AUDITORIA.registrar(
                        'intento_fuerza_bruta',
                        'critica',
                        usuario,
                        `Múltiples intentos fallidos de login (${fallidos.length + 1})`,
                        { intentos: fallidos.length + 1, ip: ip }
                    );
                }
            }

            // Registrar el intento fallido
            if (typeof AUDITORIA !== 'undefined' && AUDITORIA.registrar) {
                AUDITORIA.registrar(
                    'login_fallido',
                    'media',
                    usuario,
                    `Intento de login fallido${ip ? ' desde IP: ' + ip : ''}`,
                    { ip: ip }
                );
            }

        } catch (error) {
            console.error('❌ Error al registrar login fallido:', error);
        }
    },

    /**
     * Verificar si un usuario está bloqueado temporalmente
     */
    estaBloqueado: async function(usuario) {
        if (!usuario) return false;

        try {
            // Verificar intentos fallidos en los últimos 15 minutos
            const quinceMinutos = Date.now() - 900000;
            
            if (typeof AUDITORIA_REF === 'undefined' || AUDITORIA_REF === null) {
                return false;
            }

            const snap = await AUDITORIA_REF
                .orderByChild('timestamp')
                .startAt(quinceMinutos)
                .once('value');
            
            const data = snap.val() || {};
            const fallidos = Object.values(data).filter(a => 
                a.usuario === usuario && a.tipo === 'login_fallido'
            );

            // Si hay más de 10 intentos fallidos en 15 minutos, bloquear
            return fallidos.length >= 10;
        } catch (error) {
            console.error('❌ Error al verificar bloqueo:', error);
            return false;
        }
    },

    /**
     * Guardar en localStorage (fallback)
     */
    guardarLocal: function(usuarioDni, config) {
        localStorage.setItem('seguridad_2fa_' + usuarioDni, JSON.stringify(config));
        console.log('💾 2FA guardado en localStorage para:', usuarioDni);
    },

    /**
     * Verificar si la sesión es válida (con 2FA)
     */
    verificarSesion2FA: function() {
        try {
            const session = JSON.parse(sessionStorage.getItem('session') || 'null');
            if (!session) return false;

            const timestamp = sessionStorage.getItem('2fa_verificado_' + session.dni);
            if (!timestamp) return false;

            const tiempo = parseInt(timestamp);
            const ahora = Date.now();
            
            // La verificación 2FA expira después de 24 horas
            return (ahora - tiempo) < 24 * 60 * 60 * 1000;
        } catch (error) {
            console.error('❌ Error al verificar sesión 2FA:', error);
            return false;
        }
    },

    /**
     * Marcar sesión como verificada con 2FA
     */
    marcarSesionVerificada: function(usuarioDni) {
        if (!usuarioDni) return false;
        sessionStorage.setItem('2fa_verificado_' + usuarioDni, Date.now().toString());
        return true;
    },

    /**
     * Invalidar sesión 2FA
     */
    invalidarSesion2FA: function(usuarioDni) {
        if (!usuarioDni) return false;
        sessionStorage.removeItem('2fa_verificado_' + usuarioDni);
        return true;
    },

    /**
     * Generar log de seguridad
     */
    generarLogSeguridad: async function(usuarioDni, accion, detalles = {}) {
        if (!usuarioDni || !accion) {
            console.error('❌ Faltan datos para log de seguridad');
            return;
        }

        if (typeof AUDITORIA !== 'undefined' && AUDITORIA.registrar) {
            AUDITORIA.registrar(
                'log_seguridad',
                'media',
                usuarioDni,
                accion,
                detalles
            );
        }
    },

    /**
     * Obtener historial de seguridad de un usuario
     */
    obtenerHistorialSeguridad: async function(usuarioDni, limite = 50) {
        if (!usuarioDni) return [];

        try {
            if (typeof AUDITORIA_REF === 'undefined' || AUDITORIA_REF === null) {
                return [];
            }

            const snap = await AUDITORIA_REF
                .orderByChild('usuario')
                .equalTo(usuarioDni)
                .limitToLast(limite)
                .once('value');
            
            const data = snap.val() || {};
            const historial = Object.values(data);
            
            // Filtrar eventos de seguridad
            const eventosSeguridad = historial.filter(a => 
                a.tipo === 'login_exitoso' ||
                a.tipo === 'login_fallido' ||
                a.tipo === 'verificacion_2fa' ||
                a.tipo === 'fallo_2fa' ||
                a.tipo === 'activacion_2fa' ||
                a.tipo === 'desactivacion_2fa' ||
                a.tipo === 'intento_fuerza_bruta'
            );

            eventosSeguridad.sort((a, b) => (b.timestamp || 0) - (a.timestamp || 0));
            return eventosSeguridad;
        } catch (error) {
            console.error('❌ Error al obtener historial:', error);
            return [];
        }
    }
};

// Exportar para uso global
window.SEGURIDAD = SEGURIDAD;

console.log('✅ Sistema de Seguridad cargado correctamente');
console.log('📋 Funciones disponibles:');
console.log('  - SEGURIDAD.activar2FA()');
console.log('  - SEGURIDAD.desactivar2FA()');
console.log('  - SEGURIDAD.verificarCodigo2FA()');
console.log('  - SEGURIDAD.obtenerEstado2FA()');
console.log('  - SEGURIDAD.registrarLoginFallido()');
console.log('  - SEGURIDAD.estaBloqueado()');
console.log('  - SEGURIDAD.verificarSesion2FA()');
console.log('  - SEGURIDAD.marcarSesionVerificada()');
console.log('  - SEGURIDAD.obtenerHistorialSeguridad()');